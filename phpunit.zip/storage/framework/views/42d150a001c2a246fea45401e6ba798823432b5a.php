

<?php $__env->startSection('title', 'Hueso'); ?>

<?php $__env->startSection('imgUrl',  asset('images/rollo-de-papel.svg')); ?>

<?php $__env->startSection('namePage', 'Hueso'); ?>

<?php $__env->startSection('retornar'); ?>
<a href="<?php echo e(route('ribbonProduct.index')); ?>" ><img src="<?php echo e(asset('images/flecha-derecha.svg')); ?>" class="iconosFlechas mirror"></a>
<?php $__env->stopSection(); ?>
    
<?php $__env->startSection('form'); ?>
    <div class="row">
    <div class="col-lg-12 d-flex mt-2"> 
        <div class="col-lg-4 px-2">
            <label>Nomenclatura</label>
            <input type="text" class="form-control" name="nomenclatura" value="<?php echo e($ribbonReel->nomenclatura); ?>" disabled>
        </div>
        <div class="col-lg-4 px-2">
            <label>Peso</label>
            <input type="text" class="form-control" name="peso" value="<?php echo e($ribbonReel->peso); ?>" disabled>
        </div>
        <div class="col-lg-4 px-2">
            <label>Fecha Alta</label>
            <input type="date" class="form-control" name="status" value="<?php echo e($ribbonReel->fechaAlta); ?>" disabled>
        </div>
    </div>
    <div class="col-lg-12 d-flex mt-2">
        <div class="col-lg-4 px-2">
            <label>Status</label>
            <input type="text" class="form-control" name="status" value="<?php echo e($ribbonReel->status); ?>" disabled>
            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>s
            <br>
            <div class="alert alert-danger">
                <small><?php echo e($message); ?></small>
            </div>
            <br>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div> 
    </div>
    <div class="col-lg-12 d-flex mt-4">
        <div class="col-lg-12 px-2">
            <label>Observaciones</label>
            <textarea rows="3" class="form-control" name="observaciones" disabled><?php echo e($ribbonReel->observaciones); ?></textarea>
        </div>
    </div>
    <div class="col-lg-12 d-flex mt-5">
        <h3><img src="<?php echo e(asset('images/rollo-de-papel.svg')); ?>" class="iconoTitle">Rollo <a href="<?php echo e(route('ribbon.show', $ribbon->id)); ?>"><small>Ver Rollo</small></a> </h3>
        </div>
        
        <div class="col-lg-12 d-flex mt-3">
            <div class="col-lg-4 px-2">
                <label>Nomenclatura</label>
                <input type="text" class="form-control" name="coilNomenclatura" value="<?php echo e($ribbon->nomenclatura); ?>" disabled>
            </div>
            <div class="col-lg-4 px-2">
                <label>Fecha Adquisición</label>
                <input type="datetime" class="form-control" name="coilfArribo" value="<?php echo e($ribbon->fechaInicioTrabajo); ?>" disabled>
            </div>
            <div class="col-lg-4 px-2">
                <label>Status</label>
                <input type="text" class="form-control" name="coilStatus" value="<?php echo e($ribbon->status); ?>" disabled>
            </div>
        </div>

    <div class="col-lg-12 d-flex mt-5">
        <h3><img src="<?php echo e(asset('images/bobina.svg')); ?>" class="iconoTitle">Bobina <a href="<?php echo e(route('coil.show', $coil->id)); ?>"><small>Ver Bobina</small></a> </h3>
        </div>
        
        <div class="col-lg-12 d-flex mt-3">
            <div class="col-lg-4 px-2">
                <label>Nomenclatura</label>
                <input type="text" class="form-control" name="coilNomenclatura" value="<?php echo e($coil->nomenclatura); ?>" disabled>
            </div>
            <div class="col-lg-4 px-2">
                <label>Fecha Adquisición</label>
                <input type="datetime" class="form-control" name="coilfArribo" value="<?php echo e($coil->fArribo); ?>" disabled>
            </div>
            <div class="col-lg-4 px-2">
                <label>Status</label>
                <input type="text" class="form-control" name="coilStatus" value="<?php echo e($coil->status); ?>" disabled>
            </div>
        </div>

    

    <div class="col-12 mt-3 text-center">
        <a class="btn btn-warning mx-3" href="<?php echo e(route('ribbonReel.edit', $ribbonReel->id)); ?>">Editar</a>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.formulario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Galmonte\Desktop\MINABI-project\resources\views/ribbonReels/show.blade.php ENDPATH**/ ?>