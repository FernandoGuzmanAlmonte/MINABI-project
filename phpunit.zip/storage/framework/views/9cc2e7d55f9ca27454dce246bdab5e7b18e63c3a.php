<header>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
            <img src=<?php echo e(asset('images/logotipo.png')); ?> width="30" height="43" class="d-inline-block align-center" alt="">
            <b> MINABI </b>
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav">
                <li class="nav-item dropdown <?php echo e(request()->routeIs('employee.*', 'coilType.*', 'provider.*') ? 'active' : ''); ?>">
                    <a class="nav-link dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Catálogos
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                        <a class="dropdown-item <?php echo e(request()->routeIs('provider.*') ? 'active' : ''); ?>" href="<?php echo e(route('provider.index')); ?>">
                            Proveedores
                        </a>
                        <a class="dropdown-item <?php echo e(request()->routeIs('employee.*') ? 'active' : ''); ?>" href="<?php echo e(route('employee.index')); ?>">
                            Empleados
                        </a>
                        <a class="dropdown-item <?php echo e(request()->routeIs('coilType.*') ? 'active' : ''); ?>" href="<?php echo e(route('coilType.index')); ?>">
                            Medidas de Bobina
                        </a>
                        <a class="dropdown-item <?php echo e(request()->routeIs('user.*') ? 'active' : ''); ?>" href="<?php echo e(route('user.index')); ?>">
                            Usuarios
                        </a>
                    </div>
                </li>
                <li class="nav-item dropdown <?php echo e(request()->routeIs('whiteCoil.*', 'whiteRibbon.*', 'whiteCoilProduct.*') ? 'active' : ''); ?>">
                    <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Cinta Blanca
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                        <a class="dropdown-item <?php echo e(request()->routeIs('whiteCoil.*') ? 'active' : ''); ?>" href="<?php echo e(route('whiteCoil.index')); ?>">
                            Bobina
                        </a>
                        <a class="dropdown-item <?php echo e(request()->routeIs('whiteCoilProduct.*') ? 'active' : ''); ?>" href="<?php echo e(route('whiteCoilProduct.index')); ?>">
                            Rollos
                        </a>
                    </div>
                </li>
                <a class="nav-item nav-link <?php echo e(request()->routeIs('coil.*') ? 'active' : ''); ?>" href="<?php echo e(route('coil.index')); ?>">
                    Bobinas
                </a>
                <a class="nav-item nav-link <?php echo e(request()->routeIs('coilProduct.*') ? 'active' : ''); ?>" href="<?php echo e(route('coilProduct.index')); ?>">
                    Rollos
                </a>
                <a class="nav-item nav-link <?php echo e(request()->routeIs('bag.*', 'ribbonProduct.*') ? 'active' : ''); ?>" href="<?php echo e(route('ribbonProduct.index')); ?>">
                    Bolsas
                </a>
                
            </div>
            <form action="logout" method="POST" class="ml-lg-auto text-md-left navbar-nav">
                <?php echo csrf_field(); ?>
                <a href="#" class="nav-item nav-link" onclick="this.closest('form').submit()">Cerrar sesion</a>
            </form>      
        </div>
    </nav>
</header>    <?php /**PATH C:\Users\Galmonte\Desktop\MINABI-project\resources\views/layouts/partials/header.blade.php ENDPATH**/ ?>