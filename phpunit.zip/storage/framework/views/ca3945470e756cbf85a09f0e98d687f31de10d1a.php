

<?php $__env->startSection('title', 'Bobinas'); ?>

<?php $__env->startSection('imgUrl',  asset('images/bobina.svg')); ?>

<?php $__env->startSection('namePage', 'Bobinas ' . $coil->nomenclatura); ?>

<?php $__env->startSection('form'); ?>
<form action="<?php echo e(route('coil.update', $coil)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="row">
    <div class="col-lg-12 d-flex mt-2"> 
        <div class="col-lg-4 px-2">
            <label>Nomenclatura</label>
            <input type="text" class="form-control" name="nomenclatura" value="<?php echo e($coil->nomenclatura); ?>" id="nomenclaturas" readonly>
            <?php $__errorArgs = ['nomenclatura'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <br>
                <div class="alert alert-danger">
                    <small><?php echo e($message); ?></small>
                </div>
                <br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-lg-4 px-2">
            <label>Fecha llegada</label>
            <input type="date" class="form-control" name="fArribo" value="<?php echo e(old('fArribo', $coil->fArribo)); ?>" onblur="llenaNomen()" id="fArribo">
            <?php $__errorArgs = ['fArribo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <br>
                <div class="alert alert-danger">
                <small><?php echo e($message); ?></small>
                </div>
                <br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-lg-4 px-2">
            <label>Tipo bobina</label>
            <select class="form-control" name="coil_type_id" id="tipo" onblur="llenaNomen()">
                <?php $__currentLoopData = $coilTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coilType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php echo e(($coilType->id == $coil->coilType->id) ? 'selected' : ''); ?> value=<?php echo e($coilType->id); ?> >
                        <?php echo e($coilType->alias); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['coil_type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <br>
                <div class="alert alert-danger">
                <small><?php echo e($message); ?></small>
                </div>
                <br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="col-lg-12 d-flex mt-3">
        <div class="col-lg-4 px-2">
            <label>Proveedor</label>
            <select class="form-control" name="provider_id">
                <?php $__currentLoopData = $providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php echo e(($coil->provider->id == $provider->id)? 'selected': ''); ?> value=<?php echo e($provider->id); ?>>
                        <?php echo e($provider->nombreEmpresa); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['provider_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <br>
                <div class="alert alert-danger">
                <small><?php echo e($message); ?></small>
                </div>
                <br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-lg-4 px-2">
            <label>Status</label>
            <input type="datetime" class="form-control" name="status" value="<?php echo e($coil->status); ?>" readonly>
            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <br>
                <div class="alert alert-danger">
                <small><?php echo e($message); ?></small>
                </div>
                <br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-lg-4 px-2">
            <label>Largo (metros)</label>
            <input type="number" step="0.0001" class="form-control" name="largoM" value="<?php echo e(old('largoM', $coil->largoM)); ?>">
            <?php $__errorArgs = ['largoM'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <br>
                <div class="alert alert-danger">
                <small><?php echo e($message); ?></small>
                </div>
                <br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="col-lg-12 d-flex mt-3">
        <div class="col-lg-4 px-2">
            <label>Peso Bruto (Kg)</label>
            <input type="number" step="0.0001" class="form-control" name="pesoBruto" value="<?php echo e(old('pesoBruto', $coil->pesoBruto)); ?>">
            <?php $__errorArgs = ['pesoBruto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <br>
                <div class="alert alert-danger">
                <small><?php echo e($message); ?></small>
                </div>
                <br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-lg-4 px-2">
            <label>Peso Neto (Kg)</label>
            <input type="number" step="0.0001" class="form-control" name="pesoNeto" value="<?php echo e($coil->pesoNeto); ?>" readonly>
            <?php $__errorArgs = ['pesoNeto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <br>
                <div class="alert alert-danger">
                <small><?php echo e($message); ?></small>
                </div>
                <br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-lg-4 px-2">
            <label>Peso Utilizado (Kg)</label>
            <input type="number" step="0.0001"class="form-control" name="pesoUtilizado" value="<?php echo e($coil->pesoUtilizado); ?>" readonly>
        </div>
    </div>

    <div class="col-lg-12 d-flex mt-3">
        <div class="col-lg-4 px-2">
            <label>Diametro Exterior</label>
            <input type="number" step="0.0001" class="form-control" name="diametroExterno" value="<?php echo e(old('diametroExterno', $coil->diametroExterno)); ?>">
        </div>
        <div class="col-lg-4 px-2">
            <label>Diametro Bobina</label>
            <input type="number" step="0.0001" class="form-control" name="diametroBobina"value="<?php echo e(old('diametroBobina', $coil->diametroBobina)); ?>">
        </div>
        <div class="col-lg-4 px-2">
            <label>Diametro Interior</label>
            <input type="number" step="0.0001" class="form-control" name="diametroInterno" value="<?php echo e(old('diametroInterno', $coil->diametroInterno)); ?>">
        </div>
    </div>

    <div class="col-lg-12 d-flex mt-3">
        <div class="col-lg-4 px-2">
            <label>Costo</label>
            <input type="number" step="0.0001" class="form-control" name="costo" value="<?php echo e(old('costo', $coil->costo)); ?>">
            <?php $__errorArgs = ['costo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <br>
                <div class="alert alert-danger">
                <small><?php echo e($message); ?></small>
                </div>
                <br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="col-lg-12 d-flex mt-4">
        <div class="col-lg-12 px-2">
            <label>Observaciones</label>
            <textarea rows="3" class="form-control" name="observaciones" placeholder="Máximo 255 caracteres"><?php echo e(old('observaciones', $coil->observaciones)); ?></textarea>
            <?php $__errorArgs = ['observaciones'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <br>
                <div class="alert alert-danger">
                <small><?php echo e($message); ?></small>
                </div>
                <br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="col-12 mt-4 mb-4 text-center">
        <a class="btn btn-danger mx-3" href="<?php echo e(route('coil.show', $coil->id)); ?>">Cancelar</a>
        <button type="submit" class="btn btn-success mx-3">Guardar</button>
    </div>
</div>
</form>
<script type="text/javascript">
    function llenaNomen(){
        var fecha = document.getElementById("fArribo");
        var tipo = document.getElementById("tipo");
        var seleccion = tipo.options[tipo.selectedIndex].text;
        var folio =  document.getElementById("nomenclaturas");
        fecha = fecha.value.replace(/-/g, "");
        folio.value = "MNB"+seleccion+fecha.substring(6,8)+fecha.substring(4,6)+fecha.substring(0,4);
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.formulario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Galmonte\Desktop\MINABI-project\resources\views/coils/edit.blade.php ENDPATH**/ ?>