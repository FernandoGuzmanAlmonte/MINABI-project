

<?php $__env->startSection('title', 'Proveedores'); ?>

<?php $__env->startSection('imgUrl',  asset('images/proveedor.svg')); ?>

<?php $__env->startSection('namePage', 'Proveedor ' . $provider->id); ?>

<?php $__env->startSection('retornar'); ?>
<a href="<?php echo e(route('provider.index')); ?>" ><img src="<?php echo e(asset('images/flecha-derecha.svg')); ?>" class="iconosFlechas mirror"></a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('form'); ?>
<div class="row">
    <div class="col-lg-12 d-flex mt-2">
        <div class="col-lg-4 px-2">
            <label>Nombre Empresa</label>
            <input type="text" class="form-control" name="nombreEmpresa" value="<?php echo e($provider->nombreEmpresa); ?>" disabled>
        </div>
        <div class="col-lg-4 px-2">
            <label>Dirección</label>
            <input type="text" class="form-control" name="direccion" value="<?php echo e($provider->direccion); ?>" disabled>
        </div>
        <div class="col-lg-4 px-2">
            <label>Pagina web</label>
            <input type="text" class="form-control" name="paginaWeb" value="<?php echo e($provider->paginaWeb); ?>" disabled>
        </div>
    </div>
    <div class="col-lg-12 d-flex mt-3">
        <div class="col-lg-4 px-2">
            <label>Estado</label>
            <input type="text" class="form-control" name="estado" value="<?php echo e($provider->estado); ?>" disabled>
        </div>
    </div>
    <div class="col-12 mt-3 text-center">
        <a class="btn btn-warning mx-3" href="<?php echo e(route('provider.edit', $provider)); ?>">Editar</a>
    </div>
    
    <div class="col-lg-12 d-flex mt-5">
        <div class="col-lg-6 px-2 float-left">
            <h3><img src="<?php echo e(asset('images/contactos.svg')); ?>" class="iconoTitle"> Contactos </h3>
        </div>
        <div class="col-lg-6 px-2 mt-2 float-left">
            <button type="button" class="btn btn-success float-right mb-3" data-toggle="modal" data-target="#create" onclick="cleanModal()">
                Añadir Contacto
            </button>
        </div>
    </div>
    <div class="col-lg-12">   
    
        <?php echo $__env->make('contacts.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    
    
        <?php echo $__env->make('contacts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
    </div>
    <div class="col-lg-12 d-flex mt-5">
        <div class="col-lg-6 px-2 float-left">
            <h3><img src="<?php echo e(asset('images/bobina.svg')); ?>" class="iconoTitle"> Bobinas </h3>
        </div>
        
    </div>
    <div class="col-lg-12 d-flex">
        <table class="table table-striped mt-1 mb-5" >
            <thead class="bg-info">
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Nomenclatura</th>
                    <th scope="col">Fecha Adquisición</th>
                    <th scope="col">Tipo</th>
                    <th scope="col">Status</th>
                    <th scope="col"></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $coils; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row" class="align-middle"><?php echo e($coil->id); ?></th>
                    <td class="align-middle"><?php echo e($coil->nomenclatura); ?></td>
                    <td class="align-middle"><?php echo e($coil->fArribo); ?></td>
                    <td class="align-middle"><?php echo e($coil->coil_type_id); ?></td>
                    <td class="align-middle">
                        <label class="btn btn-outline-<?php echo e(($coil->status == 'DISPONIBLE') ? 'success' : 'danger'); ?> m-0">
                            <?php echo e($coil->status); ?>

                        </label>
                    </td>
                    <td><a href="<?php echo e(route('coil.show', $coil)); ?>"><img src="<?php echo e(asset('images/flecha-derecha.svg')); ?>" class="iconosFlechas"></a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
    function formValidation()
    {
        var formBagMeasure = $("#formContact");
        var formData = formBagMeasure.serialize(); //variable con el valor de todos los input del formulario

        //Limpiamos el contenido de los div de errores
        cleanErrorsModal();

        $.ajax({
            url: "<?php echo e(route('provider.store')); ?>",
            type: 'POST',
            data: formData,
            success: function(response)
                     {
                        if (response)
                        {
                            $('#create').modal('toggle'); //cerramos modal #create
                            location.reload(); // recargamos la página
                        }
                     },
            error: function(response)
                   {
                        if(errorMessageTelefono = response.responseJSON.errors.telefono)
                        {
                            $(".telefono-error").html(
                                '<div class="alert alert-danger mt-2">' +
                                    '<small>'+ errorMessageTelefono +'</small>' +
                                '</div>');
                        }
                        if(errorMessageNombre = response.responseJSON.errors.nombre)
                        {
                            $(".nombre-error").html(
                                '<div class="alert alert-danger mt-2">' +
                                    '<small>'+ errorMessageNombre +'</small>' +
                                '</div>');
                        }
                        if(errorMessageApellidos = response.responseJSON.errors.apellidos)
                        {
                            $(".apellidos-error").html(
                                '<div class="alert alert-danger mt-2">' +
                                    '<small>'+ errorMessageApellidos +'</small>' +
                                '</div>');
                        }
                        if(errorMessageCorreoElectronico = response.responseJSON.errors.correoElectronico)
                        {
                            $(".correoElectronico-error").html(
                                '<div class="alert alert-danger mt-2">' +
                                    '<small>'+ errorMessageCorreoElectronico +'</small>' +
                                '</div>');
                        }
                   }
        });
    }
    function cleanModal()
    {
        cleanErrorsModal();
        cleanInputValueModal();
    }
    function cleanErrorsModal()
    {
        //Limpiamos el contenido de los div de errores del modal #create
        $(".telefono-error").html('');
        $(".nombre-error").html('');
        $(".apellidos-error").html('');
        $(".correoElectronico-error").html(''); 
    }
    function cleanInputValueModal()
    {
        //Limpiamos el contenido de los input del modal #create
        $('input[name=telefono]').val('');
        $('input[name=nombre]').val('');
        $('input[name=apellidos]').val('');
        $('input[name=correoElectronico]').val('');
    }

    //Funciones para el form modal de Edit

    function formValidationEdit(item)
    {
        var idContact = item.id;

        var formContactEdit = $('#formContactEdit' + idContact);
        var formData = formContactEdit.serialize(); //variable con el valor de todos los input del formulario

        //Se guarda la ruta provider.update en la variable url        
        var url = formContactEdit.attr('action');

        //Limpiamos el contenido de los div de errores
        cleanErrorsModalEdit(idContact);

        $.ajax({
            url: url,
            type: 'POST',
            data: formData,
            success: function(response)
                     {
                        if (response)
                        {
                            $('#edit'+ idContact).modal('toggle'); //cerramos modal #edit
                            location.reload(); // recargamos la página
                        }
                     },
            error: function(response)
                   {
                        if(errorMessageTelefono = response.responseJSON.errors.telefono)
                        {
                            $(".telefono-error"+ idContact).html(
                                '<div class="alert alert-danger mt-2">' +
                                    '<small>'+ errorMessageTelefono +'</small>' +
                                '</div>');
                        }
                        if(errorMessageNombre = response.responseJSON.errors.nombre)
                        {
                            $(".nombre-error"+ idContact).html(
                                '<div class="alert alert-danger mt-2">' +
                                    '<small>'+ errorMessageNombre +'</small>' +
                                '</div>');
                        }
                        if(errorMessageApellidos = response.responseJSON.errors.apellidos)
                        {
                            $(".apellidos-error"+ idContact).html(
                                '<div class="alert alert-danger mt-2">' +
                                    '<small>'+ errorMessageApellidos +'</small>' +
                                '</div>');
                        }
                        if(errorMessageCorreoElectronico = response.responseJSON.errors.correoElectronico)
                        {
                            $(".correoElectronico-error"+ idContact).html(
                                '<div class="alert alert-danger mt-2">' +
                                    '<small>'+ errorMessageCorreoElectronico +'</small>' +
                                '</div>');
                        }
                   }
        });
    }
    function cleanErrorsModalEdit(idContact)
    {
        //Limpiamos el contenido de los input del modal #editID
        $(".telefono-error"+ idContact).html('');
        $(".nombre-error"+ idContact).html('');
        $(".apellidos-error"+ idContact).html('');
        $(".correoElectronico-error"+ idContact).html(''); 
    }
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.formulario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Galmonte\Desktop\MINABI-project\resources\views/providers/show.blade.php ENDPATH**/ ?>