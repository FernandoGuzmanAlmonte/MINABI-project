

<?php $__env->startSection('content'); ?>
<div class="container">
    
    <h1 class="mt-5"><img src="<?php echo $__env->yieldContent('imgUrl'); ?>" class="iconoTitle"> <?php echo $__env->yieldContent('namePage'); ?> </h1>

<!-- Filtrado -->
    <?php echo $__env->yieldContent('filtrado'); ?>

<!-- tabla -->
<table class="table table-striped my-4" >
    <thead class="bg-info">
        <!--info de cada tabla-->
        <?php echo $__env->yieldContent('table'); ?>
      
    </tbody>
  </table>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Galmonte\Desktop\MINABI-project\resources\views/layouts/tablaIndexSinAgregar.blade.php ENDPATH**/ ?>