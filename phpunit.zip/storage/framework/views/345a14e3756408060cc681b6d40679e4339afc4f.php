

<?php $__env->startSection('title', 'Bobinas'); ?>

<?php $__env->startSection('imgUrl',  asset('images/bobina.svg')); ?>

<?php $__env->startSection('namePage', 'Bobinas'); ?>

<?php $__env->startSection('retornar'); ?>
<a href="<?php echo e(route('coil.index')); ?>" ><img src="<?php echo e(asset('images/flecha-derecha.svg')); ?>" class="iconosFlechas mirror"></a>
<?php $__env->stopSection(); ?>
    
<?php $__env->startSection('form'); ?>
    <div class="row">
    <div class="col-lg-12 d-flex mt-2"> 
        <div class="col-lg-4 px-2">
            <label>Nomenclatura</label>
            <input type="text" class="form-control" name="nomenclatura" value="<?php echo e($coil->nomenclatura); ?>" disabled>
        </div>
        <div class="col-lg-4 px-2">
            <label>Fecha llegada</label>
            <input type="datetime" class="form-control" name="fArribo" value="<?php echo e($coil->fArribo); ?>" disabled>
        </div>
        <div class="col-lg-4 px-2">
            <label>Tipo bobina</label>
            <input type="text" class="form-control" name="idTipoBobina" value="<?php echo e($coil->coilType->alias); ?>" disabled>
        </div>
    </div>

    <div class="col-lg-12 d-flex mt-3">
        <div class="col-lg-4 px-2">
            <label>Proveedor</label>
            <input type="text" class="form-control" name="provider_id" value="<?php echo e($coil->provider->nombreEmpresa); ?>" disabled>
        </div>
        <div class="col-lg-4 px-2 disponible">
            <label>Status</label>
            <input type="datetime" class="form-control" name="status" value="<?php echo e($coil->status); ?>" disabled>
        </div>
        <div class="col-lg-4 px-2">
            <label>Largo (metros)</label>
            <input type="text" class="form-control" name="largoM" value="<?php echo e($coil->largoM); ?>" disabled>
        </div>
    </div>

    <div class="col-lg-12 d-flex mt-3">
        <div class="col-lg-4 px-2">
            <label>Peso Bruto (Kg)</label>
            <input type="text" class="form-control" name="pesoBruto" value="<?php echo e($coil->pesoBruto); ?>" disabled>
        </div>
        <div class="col-lg-4 px-2">
            <label>Peso Neto (Kg)</label>
            <input type="datetime" class="form-control" name="pesoNeto" value="<?php echo e($coil->pesoNeto); ?>" disabled>
        </div>
        <div class="col-lg-4 px-2">
            <label>Peso Utilizado (Kg)</label>
            <input type="text" class="form-control" name="pesoUtilizado" value="<?php echo e($coil->pesoUtilizado); ?>" disabled>
        </div>
    </div>

    <div class="col-lg-12 d-flex mt-3">
        <div class="col-lg-4 px-2">
            <label>Diametro Exterior</label>
            <input type="text" class="form-control" name="diametroExterno" value="<?php echo e($coil->diametroExterno); ?>" disabled>
        </div>
        <div class="col-lg-4 px-2">
            <label>Diametro Bobina</label>
            <input type="datetime" class="form-control" name="diametroBobina"value="<?php echo e($coil->diametroBobina); ?>" disabled>
        </div>
        <div class="col-lg-4 px-2">
            <label>Diametro Interior</label>
            <input type="text" class="form-control" name="diametroInterno" value="<?php echo e($coil->diametroInterno); ?>" disabled>
        </div>
    </div>

    <div class="col-lg-12 d-flex mt-3">
        <div class="col-lg-4 px-2">
            <label>Costo</label>
            <input type="text" class="form-control" name="costo" value="<?php echo e($coil->costo); ?>" disabled>
        </div>
    </div>

    <div class="col-lg-12 d-flex mt-4">
        <div class="col-lg-12 px-2">
            <label>Observaciones</label>
            <textarea rows="3" class="form-control" name="observaciones" disabled><?php echo e($coil->observaciones); ?></textarea>
        </div>
    </div>
    <div class="col-12 mt-5 text-center">
        <a class="btn btn-warning mx-3 mb-5" href="<?php echo e(route('coil.edit', $coil->id)); ?>">Editar</a>
        <button class="btn btn-danger mx-3 mb-5"  onclick="terminar(<?php echo e($coil->id); ?>)" href="<?php echo e(route('coil.terminar', $coil->id)); ?>">Terminar</button>
        <?php if($errors->any()): ?>
        <div class="col-12 mt-3 text-center">
            <br>
                <div class="alert alert-danger">
                    <?php echo e($errors->first()); ?>

                </div>
                <br>
        </div>
        <?php endif; ?>
    </div>
    <div class="col-lg-12 my-3">
    <h3><img src="<?php echo e(asset('images/rollo-de-papel.svg')); ?>" class="iconoTitle"> Rollos </h3>
    <a class="btn btn-success float-right mb-3"  data-toggle="modal" data-target="#createProduct">Nuevo Rollo</a>
    <!--Tabla para rollos relacionados-->
    <table class="table table-striped my-4" >
        <thead class="bg-info">
    <tr>
        <th scope="col">#</th>
        <th scope="col">Nomenclatura</th>
        <th scope="col">Peso</th>
        <th scope="col">Fecha Adquisición</th>
        <th scope="col">Status</th>
        <th scope="col"></th>
      </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $ribbons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row" class="align-middle"><?php echo e($item->id); ?></th>
            <td class="align-middle"><?php echo e($item->nomenclatura); ?></td>
            <td class="align-middle"><?php echo e($item->peso); ?></td>
            <td class="align-middle"><?php echo e($item->fAdquisicion); ?></td>
            <td class="align-middle">
                <label class="btn btn-outline-<?php echo e(($item->status == 'DISPONIBLE') ? 'success' : 'danger'); ?> m-0">
                    <?php echo e($item->status); ?>

                </label>
            </td>
           <!--Realizamos if para validacion de adonde dirgir el show-->
        <?php if($item->coil_product_type == 'App\Models\Ribbon'): ?>
        <td><a href="<?php echo e(route('ribbon.show',$item->coil_product_id)); ?>"><img src="<?php echo e(asset('images/flecha-derecha.svg')); ?>" class="iconosFlechas"></a></td>
        <?php elseif($item->coil_product_type == 'App\Models\WasteRibbon'): ?>
        <td><a href="<?php echo e(route('wasteRibbon.show',$item->coil_product_id)); ?>"><img src="<?php echo e(asset('images/flecha-derecha.svg')); ?>" class="iconosFlechas"></a></td>
        <?php elseif($item->coil_product_type == 'App\Models\CoilReel'): ?>
        <td><a href="<?php echo e(route('coilReel.show',$item->coil_product_id)); ?>"><img src="<?php echo e(asset('images/flecha-derecha.svg')); ?>" class="iconosFlechas"></a></td>
        <?php endif; ?>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table>

<!--Tabla para bolsas relacionadas-->
<h3 class="mt-5"> <img src="<?php echo e(asset('images/bolsa-de-papel.svg')); ?>" class="iconoTitle"> Bolsas </h3>
<table class="table table-striped my-4" >
    <thead class="bg-info">
<tr>
    <th scope="col">#</th>
    <th scope="col">Nomenclatura</th>
    <th scope="col">Peso</th>
    <th scope="col">Medida</th>
    <th scope="col">Fecha Adquisición</th>
    <th scope="col">Status</th>
    <th scope="col"></th>
  </tr>
</thead>
<tbody>
    <?php $__currentLoopData = $ribbonProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr>
        <th scope="row" class="align-middle"><?php echo e($item->id); ?></th>
        <td class="align-middle"><?php echo e($item->nomenclatura); ?></td>
        <td class="align-middle"><?php echo e($item->peso); ?></td>
        <td class="align-middle"><?php echo e($item->medidaBolsa); ?></td>
        <td class="align-middle"><?php echo e($item->fAdquisicion); ?></td>
        <td class="align-middle"><label class="btn btn-outline-<?php echo e(($item->status == 'DISPONIBLE') ? 'success' : 'danger'); ?> m-0"><?php echo e($item->status); ?></label></td>
       <!--Realizamos if para validacion de adonde dirgir el show-->
    <?php if($item->ribbon_product_type == 'App\Models\Bag'): ?>
    <td><a href="<?php echo e(route('bag.show',$item->ribbon_product_id)); ?>"><img src="<?php echo e(asset('images/flecha-derecha.svg')); ?>" class="iconosFlechas"></a></td>
    <?php elseif($item->ribbon_product_type == 'App\Models\WasteBag'): ?>
    <td><a href="<?php echo e(route('wasteBag.show',$item->ribbon_product_id)); ?>"><img src="<?php echo e(asset('images/flecha-derecha.svg')); ?>" class="iconosFlechas"></a></td>
    <?php elseif($item->ribbon_product_type == 'App\Models\RibbonReel'): ?>
    <td><a href="<?php echo e(route('ribbonReel.show',$item->ribbon_product_id)); ?>"><img src="<?php echo e(asset('images/flecha-derecha.svg')); ?>" class="iconosFlechas"></a></td>
    <?php endif; ?>
    </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>    
</div>
</div>
<?php echo $__env->make('coils.modalTypeSelection', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script type="text/javascript">
    function terminar(id){
        var opcion = confirm("¿Esta seguro que desea terminar la bobina?");
        if (opcion == true) {
        location.replace ("http://localhost/MINABI-project/public/coil/terminar/"+id)
	    } 
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.formulario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Galmonte\Desktop\MINABI-project\resources\views/coils/show.blade.php ENDPATH**/ ?>