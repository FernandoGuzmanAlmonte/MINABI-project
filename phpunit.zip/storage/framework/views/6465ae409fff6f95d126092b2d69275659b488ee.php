

<?php $__env->startSection('title', 'Reporte bobinas'); ?>

<?php $__env->startSection('imgUrl',  asset('images/bobina.svg')); ?>

<?php $__env->startSection('namePage', 'Reporte de almacen de bobinas'); ?>

<?php $__env->startSection('table'); ?>
<script type="text/javascript">

    var array = [];
    var i = 0;

    function proveedores(idProveedor){
        array.push(idProveedor); 
        console.log(array);
    }

    function insertar(idObjecto){
       for(; i){

       }
    }
    </script>
<table class="table table-striped my-4" id="tabla">
    <thead class="bg-info">
        <tr>
            
            <?php $__currentLoopData = $providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <script languaje="javascript">
                var id = "<?php echo e($provider->id); ?>"
                proveedores(id);
            </script>
                <th id="col <?php echo e($provider->id); ?>"><?php echo e($provider->nombreEmpresa); ?></th>
                <th>Peso (KG)</th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tr>
</thead>
<tbody >
    <?php echo e($anterior = $bobinas[0]->medida); ?>

    <tr>
    <?php $__currentLoopData = $bobinas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($anterior != $item->medida): ?>
    <tr>
    <?php endif; ?>

    <td scope="row" class="align-middle"><?php echo e($item->cantidad); ?></td>
    <td class="align-middle"><?php echo e($item->peso); ?></td>
    
    <?php echo e($anterior = $item->medida); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.tablaIndexSinAgregar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Galmonte\Desktop\MINABI-project\resources\views/coils/reporteria.blade.php ENDPATH**/ ?>