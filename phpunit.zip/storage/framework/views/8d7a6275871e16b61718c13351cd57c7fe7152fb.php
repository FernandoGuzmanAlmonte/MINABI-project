<table class="table table-striped mt-1 mb-5" >
    <thead class="bg-info">
        <tr>
            <th scope="col">#</th>
            <th scope="col">Télefono</th>
            <th scope="col">Nombre(s)</th>
            <th scope="col">Apellidos</th>
            <th scope="col">Correo electrónico</th>
            <th scope="col">Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row" class="align-middle"><?php echo e($contact->id); ?></th>
                <td class="align-middle"><?php echo e($contact->telefono); ?></td>
                <td class="align-middle"><?php echo e($contact->nombre); ?></td>
                <td class="align-middle"><?php echo e($contact->apellidos); ?></td>
                <td class="align-middle"><?php echo e($contact->correoElectronico); ?></td>
                <td class="align-middle">
                    
                    <?php echo $__env->make('contacts.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    
                    <form action="<?php echo e(route('provider.destroy', $contact->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <a href="<?php echo e(route('provider.edit', $contact->id)); ?>" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#edit<?php echo e($contact->id); ?>">
                            <img src="<?php echo e(asset('images/icono-editar.svg')); ?>" class="iconosPequeños">
                        </a>
                        <button type="submit" class="btn btn-danger btn-sm">
                            <img src="<?php echo e(asset('images/icono-eliminar.svg')); ?>" class="iconosPequeños">
                        </button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\Users\Galmonte\Desktop\MINABI-project\resources\views/contacts/index.blade.php ENDPATH**/ ?>