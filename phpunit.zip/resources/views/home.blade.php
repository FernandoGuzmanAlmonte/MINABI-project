@extends('layouts.plantilla')

@section('content')
<div class="container">
    <div class=" justify-content-center text-center mt-4">
        <img src={{ asset('images/logotipo.png') }} width="170" height="300" class="my-5" alt="">
    </div>
</div>
@endsection
