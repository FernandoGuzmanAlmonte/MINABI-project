<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class WhiteRibbonProductController extends Controller
{
    //
}
