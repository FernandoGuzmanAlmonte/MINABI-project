

<?php $__env->startSection('title', 'Editar Medida de Bobina'); ?>

<?php $__env->startSection('imgUrl',  asset('images/bobina.svg')); ?>

<?php $__env->startSection('namePage', 'Editar Tipo de Bobina ' . $coilType->alias); ?>

<?php $__env->startSection('form'); ?>
<form action="<?php echo e(route('coilType.update', $coilType)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="row">
        <div class="col-lg-12 d-flex mt-2">
            <div class="col-lg-4 px-2">
                <label><span class="required">*</span> Alias</label>
                <input type="text" class="form-control" name="alias" value="<?php echo e(old('alias', $coilType->alias)); ?>">
                <?php $__errorArgs = ['alias'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger mt-2">
                        <small><?php echo e($message); ?></small>
                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-lg-4 px-2">
                <label><span class="required">*</span> Ancho (cm)</label>
                <input type="number" step="0.0001" class="form-control" name="anchoCm" value="<?php echo e(old('anchoCm', $coilType->anchoCm)); ?>">
                <?php $__errorArgs = ['anchoCm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger mt-2">
                        <small><?php echo e($message); ?></small>
                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-lg-4 px-2">
                <label><span class="required">*</span> Largo (m)</label>
                <input type="number" step="0.0001" class="form-control" name="largoM" value="<?php echo e(old('largoM', $coilType->largoM)); ?>">
                <?php $__errorArgs = ['largoM'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger mt-2">
                        <small><?php echo e($message); ?></small>
                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="col-lg-12 d-flex mt-3">
            <div class="col-lg-4 px-2">
                <label><span class="required">*</span> Densidad</label>
                <input type="number" step="0.0001" class="form-control" name="densidad" value="<?php echo e(old('densidad', $coilType->densidad)); ?>">
                <?php $__errorArgs = ['densidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger mt-2">
                        <small><?php echo e($message); ?></small>
                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-lg-4 px-2">
                <label><span class="required">*</span> Material</label>
                <input type="text" class="form-control" name="material" value="<?php echo e(old('material', $coilType->material)); ?>">
                <?php $__errorArgs = ['material'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger mt-2">
                        <small><?php echo e($message); ?></small>
                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-lg-4 px-2">
                <label><span class="required">*</span> Calibre</label>
                <input type="number" step="0.0001" class="form-control" name="calibre" value="<?php echo e(old('calibre', $coilType->calibre)); ?>">
                <?php $__errorArgs = ['calibre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger mt-2">
                        <small><?php echo e($message); ?></small>
                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="col-lg-12 d-flex mt-3">
            <div class="col-lg-4 px-2">
                <label><span class="required">*</span> Tipo</label>
                <select class="form-control" name="tipo">
                    <option <?php echo e((old('tipo', $coilType->tipo) == 'CELOFAN') ? 'selected' : ''); ?> value="CELOFAN">CELOFÁN</option>
                    <option <?php echo e((old('tipo', $coilType->tipo) == 'CENEFA') ? 'selected' : ''); ?> value="CENEFA">CENEFA</option>
                </select>
                <?php $__errorArgs = ['tipo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger mt-2">
                        <small><?php echo e($message); ?></small>
                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="col-lg-12 d-flex mt-4">
            <div class="col-lg-12 px-2">
                <label>Observaciones</label>
                <textarea rows="3" class="form-control" name="observaciones" placeholder="Máximo 255 caracteres"><?php echo e(old('observaciones', $coilType->observaciones)); ?></textarea>
                <?php $__errorArgs = ['observaciones'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger mt-2">
                        <small><?php echo e($message); ?></small>
                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="col-12 mt-4 mb-4 text-center">
            <a class="btn btn-danger mx-3" href="<?php echo e(route('coilType.show', $coilType)); ?>">Cancelar</a>
            <button type="submit" name="coilTypeForm" class="btn btn-success mx-3">Guardar</button>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.formulario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Galmonte\Desktop\MINABI-project\resources\views/coilTypes/edit.blade.php ENDPATH**/ ?>