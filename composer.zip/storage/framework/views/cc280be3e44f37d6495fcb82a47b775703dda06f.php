

<?php $__env->startSection('title', 'Medida de Bobina'); ?>

<?php $__env->startSection('imgUrl',  asset('images/bobina.svg')); ?>

<?php $__env->startSection('namePage', 'Medida de Bobina ' . $coilType->alias); ?>

<?php $__env->startSection('retornar'); ?>
<a href="<?php echo e(route('coilType.index')); ?>" ><img src="<?php echo e(asset('images/flecha-derecha.svg')); ?>" class="iconosFlechas mirror"></a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('form'); ?>
<div class="row">
    <div class="col-lg-12 d-flex mt-2">
        <div class="col-lg-4 px-2">
            <label>Alias</label>
            <input type="text" class="form-control" name="alias" value="<?php echo e($coilType->alias); ?>" disabled>
        </div>
        <div class="col-lg-4 px-2">
            <label>Ancho (cm)</label>
            <input type="number" step="0.0001" class="form-control" name="anchoCm" value="<?php echo e($coilType->anchoCm); ?>" disabled>
        </div>
        <div class="col-lg-4 px-2">
            <label>Largo (m)</label>
            <input type="number" step="0.0001" class="form-control" name="largoM" value="<?php echo e($coilType->largoM); ?>" disabled>
        </div>
    </div>
    <div class="col-lg-12 d-flex mt-3">
        <div class="col-lg-4 px-2">
            <label>Densidad</label>
            <input type="number" step="0.0001" class="form-control" name="densidad" value="<?php echo e($coilType->densidad); ?>" disabled>
        </div>
        <div class="col-lg-4 px-2">
            <label>Material</label>
            <input type="text" class="form-control" name="material" value="<?php echo e($coilType->material); ?>" disabled>
        </div>
        <div class="col-lg-4 px-2">
            <label>Calibre</label>
            <input type="text" class="form-control" name="calibre" value="<?php echo e($coilType->calibre); ?>" disabled>
        </div>
    </div>
    <div class="col-lg-12 d-flex mt-3">
        <div class="col-lg-4 px-2">
            <label>Tipo</label>
            <input type="text" class="form-control" name="tipo" value="<?php echo e(($coilType->tipo == 'CELOFAN') ? 'CELOFÁN' : 'CENEFA'); ?>" disabled>
        </div>
    </div>
    <div class="col-lg-12 d-flex mt-4">
        <div class="col-lg-12 px-2">
            <label>Observaciones</label>
            <textarea rows="3" class="form-control" name="observaciones" disabled><?php echo e($coilType->observaciones); ?></textarea>
        </div>
    </div>
    <div class="col-12 mt-4 mb-4 text-center">
        <a class="btn btn-warning mx-3" href="<?php echo e(route('coilType.edit', $coilType)); ?>">Editar</a>
    </div>
    
    <div class="col-lg-12 d-flex mt-5">
        <div class="col-lg-6 px-2 float-left">
            <h3><img src="<?php echo e(asset('images/bolsa-de-papel.svg')); ?>" class="iconoTitle"> Medidas de Bolsas </h3>
        </div>
        <div class="col-lg-6 px-2 mt-2 float-left">
            <button type="button" class="btn btn-success float-right mb-3" data-toggle="modal" data-target="#create" onclick="cleanModal()">
                Añadir Medida de Bolsa
            </button>
        </div>
    </div>
    <div class="col-lg-12">   
        
            <?php echo $__env->make('bagMeasures.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        
        
            <?php echo $__env->make('bagMeasures.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
    function formValidation()
    {
        var formBagMeasure = $("#formBagMeasure");
        var formData = formBagMeasure.serialize(); //variable con el valor de todos los input del formulario

        //Limpiamos el contenido de los div de errores
        cleanErrorsModal();

        $.ajax({
            url: "<?php echo e(route('coilType.store')); ?>",
            type: 'POST',
            data: formData,
            success: function(response)
                     {
                        if (response)
                        {
                            $('#create').modal('toggle'); //cerramos modal #create
                            location.reload(); // recargamos la página
                        }
                     },
            error: function(response)
                   {
                        if(errorMessageAncho = response.responseJSON.errors.ancho)
                        {
                            $(".ancho-error").html(
                                '<div class="alert alert-danger mt-2">' +
                                    '<small>'+ errorMessageAncho +'</small>' +
                                '</div>');
                        }
                        if(errorMessageLargo = response.responseJSON.errors.largo)
                        {
                            $(".largo-error").html(
                                '<div class="alert alert-danger mt-2">' +
                                    '<small>'+ errorMessageLargo +'</small>' +
                                '</div>');
                        }
                   }
        });
    }
    function cleanModal()
    {
        cleanErrorsModal();
        cleanInputValueModal();
    }
    function cleanErrorsModal()
    {
        //Limpiamos el contenido de los div de errores del modal #create
        $(".ancho-error").html('');
        $(".largo-error").html(''); 
    }
    function cleanInputValueModal()
    {
        //Limpiamos el contenido de los input del modal #create
        $('input[name=largo]').val('');
        $('input[name=ancho]').val('');
    }

    //Funciones para el form modal de Edit

    function formValidationEdit(item)
    {
        var idBagMeasure = item.id;

        var formBagMeasureEdit = $('#formBagMeasureEdit' + idBagMeasure);
        var formData = formBagMeasureEdit.serialize(); //variable con el valor de todos los input del formulario

        //Limpiamos el contenido de los div de errores
        cleanErrorsModalEdit(idBagMeasure);

        //Aqui guardamos la ruta con un id temporal
        var url = "route('coilType.update', ['id' => 'temp'])";
        //Aqui sustituimos la variable temp por el id de bagMeasure
        url = url.replace('temp', idBagMeasure);
        
        $.ajax({
            url: "/coilType/" + idBagMeasure,
            type: 'POST',
            data: formData,
            success: function(response)
                     {
                        if (response)
                        {
                            $('#edit'+ idBagMeasure).modal('toggle'); //cerramos modal #create
                            location.reload(); // recargamos la página
                        }
                     },
            error: function(response)
                   {
                        if(errorMessageAncho = response.responseJSON.errors.ancho)
                        {
                            $(".ancho-error"+ idBagMeasure).html(
                                '<div class="alert alert-danger mt-2">' +
                                    '<small>'+ errorMessageAncho +'</small>' +
                                '</div>');
                        }
                        if(errorMessageLargo = response.responseJSON.errors.largo)
                        {
                            $(".largo-error"+ idBagMeasure).html(
                                '<div class="alert alert-danger mt-2">' +
                                    '<small>'+ errorMessageLargo +'</small>' +
                                '</div>');
                        }
                   }
        });
    }
    function cleanErrorsModalEdit(idBagMeasure)
    {
        //Limpiamos el contenido de los input del modal #editID
        $(".ancho-error"+ idBagMeasure).html('')
        $(".largo-error"+ idBagMeasure).html(''); 
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.formulario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Galmonte\Desktop\MINABI-project\resources\views/coilTypes/show.blade.php ENDPATH**/ ?>