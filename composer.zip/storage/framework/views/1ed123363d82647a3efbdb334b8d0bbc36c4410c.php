

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->yieldContent('retornar'); ?>
        
        <h1 class="mt-5"> <img src="<?php echo $__env->yieldContent('imgUrl'); ?>" class="iconoTitle"> <?php echo $__env->yieldContent('namePage'); ?> </h1>
        <h3> Información General </h3>
    <!-- Formulario -->
        <?php echo $__env->yieldContent('form'); ?>
    </div>
<?php $__env->stopSection(); ?>

    
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Galmonte\Desktop\MINABI-project\resources\views/layouts/formulario.blade.php ENDPATH**/ ?>