<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

<!-- Shortcut icon -->
    <link rel="shortcut icon" href="<?php echo e(asset('images/logotipo.png')); ?>">

<!-- Título -->
    <title> <?php echo $__env->yieldContent('title'); ?> </title>

<!-- Bootstrap -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
<!-- HTML -->
    <link rel="stylesheet" href="<?php echo e(asset('css/general.css')); ?>"/>

<!--JS-->    
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
<!--Daterangepicker-->     
    <script type="text/javascript" src="//cdn.jsdelivr.net/jquery/1/jquery.min.js"></script>
    <script type="text/javascript" src="//cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
    <script type="text/javascript" src="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.js"></script>
    <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.css" />
</head>
<body>
<!-- Navbar -->
    <?php echo $__env->make('layouts.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Contenido -->
    <?php echo $__env->yieldContent('content'); ?>
<!-- Scripts -->       
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html><?php /**PATH C:\Users\Galmonte\Desktop\MINABI-project\resources\views/layouts/plantilla.blade.php ENDPATH**/ ?>