

<?php $__env->startSection('title', 'Rollo'); ?>

<?php $__env->startSection('imgUrl',  asset('images/cinta.svg')); ?>

<?php $__env->startSection('namePage', 'Rollo'); ?>

<?php $__env->startSection('retornar'); ?>
<a href="<?php echo e(route('whiteCoilProduct.index')); ?>" ><img src="<?php echo e(asset('images/flecha-derecha.svg')); ?>" class="iconosFlechas mirror"></a>
<?php $__env->stopSection(); ?>
    
<?php $__env->startSection('form'); ?>
    <div class="row">
    <div class="col-lg-12 d-flex mt-2"> 
        <div class="col-lg-4 px-2">
            <label>Nomenclatura</label>
            <input type="text" class="form-control" name="nomenclatura" value="<?php echo e($whiteRibbon->nomenclatura); ?>" disabled>
        </div>
        <div class="col-lg-4 px-2">
            <label>Status</label>
            <input type="text" class="form-control" name="status" value="<?php echo e($whiteRibbon->status); ?>" disabled>
        </div>
        <div class="col-lg-4 px-2">
            <label>Peso (KG)</label>
            <input type="text" class="form-control" name="peso" value="<?php echo e($whiteRibbon->peso); ?>" disabled>
        </div>
    </div>

    <div class="col-lg-12 d-flex mt-3">
        <div class="col-lg-4 px-2">
            <label>Fecha Alta</label>
            <input type="text" class="form-control" name="fArribo" value="<?php echo e($whiteRibbon->fArribo); ?>" disabled>
        </div>
        <div class="col-lg-4 px-2">
            <label>Largo (metros)</label>
            <input type="text" class="form-control" name="largo" value="<?php echo e($whiteRibbon->largo); ?>" disabled>
        </div>
        <div class="col-lg-4 px-2">
            <label>Peso Utilizado (KG)</label>
            <input type="datetime" class="form-control" name="pesoUtilizado" value="<?php echo e($whiteRibbon->pesoUtilizado); ?>" disabled>
        </div>
    </div>

    <div class="col-lg-12 d-flex mt-4">
        <div class="col-lg-12 px-2">
            <label>Observaciones</label>
            <textarea rows="3" class="form-control" name="observaciones" disabled><?php echo e($whiteRibbon->observaciones); ?></textarea>
        </div>
    </div>

    

    <div class="col-12 mt-2 mb-2 text-center">
        <a class="btn btn-warning mx-3" href="<?php echo e(route('whiteRibbon.edit', $whiteRibbon->id)); ?>">Editar</a>
    </div>

    <div class="col-lg-12 d-flex mt-5">
    <h3><img src="<?php echo e(asset('images/base-de-datos.svg')); ?>" class="iconoTitle">Bobina de cinta blanca <a href="<?php echo e(route('whiteCoil.show', $whiteCoil->id)); ?>"><small>Ver Bobina</small></a> </h3>
    </div>
    
    <div class="col-lg-12 d-flex mt-3">
        <div class="col-lg-4 px-2">
            <label>Nomenclatura</label>
            <input type="text" class="form-control" name="coilNomenclatura" value="<?php echo e($whiteCoil->nomenclatura); ?>" disabled>
        </div>
        <div class="col-lg-4 px-2">
            <label>Fecha Adquisición</label>
            <input type="datetime" class="form-control" name="coilfArribo" value="<?php echo e($whiteCoil->fArribo); ?>" disabled>
        </div>
        <div class="col-lg-4 px-2">
            <label>Status</label>
            <input type="text" class="form-control" name="coilStatus" value="<?php echo e($whiteCoil->status); ?>" disabled>
        </div>
    </div>

    
    <div class="col-lg-12 my-5">
        <h3><img src="<?php echo e(asset('images/rollo-de-papel.svg')); ?>" class="iconoTitle"> Mermas de Cinta blanca y Rollos de celofan</h3>
        <a class="btn btn-success float-right mb-3"  data-toggle="modal" data-target="#createProduct">Nueva Producto</a>
        
        <table class="table table-striped my-4" >
            <thead class="bg-info">
        <tr>
            <th scope="col">#</th>
            <th scope="col">Nomenclatura</th>
            <th scope="col">Largo</th>
            <th scope="col">Fecha Adquisición</th>
            <th scope="col">Status</th>
            <th scope="col"></th>
          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $bag; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
            <tr>
                <th scope="row" class="align-middle"><?php echo e($item->id); ?></th>
                <td class="align-middle"><?php echo e($item->nomenclatura); ?></td>
                <td class="align-middle"><?php echo e($item->largo); ?></td>
                <td class="align-middle"><?php echo e($item->fAdquisicion); ?></td>
                <td class="align-middle"><label class="btn btn-outline-<?php echo e(($item->status == 'DISPONIBLE') ? 'success' : 'danger'); ?> m-0"><?php echo e($item->status); ?></label></td>
               <!--Realizamos if para validacion de adonde dirgir el show-->
            <?php if($item->white_ribbon_product_type == 'App\Models\WhiteRibbonReel'): ?>
            <td><a href="<?php echo e(route('whiteRibbonReel.show',$item->white_ribbon_product_id)); ?>"><img src="<?php echo e(asset('images/flecha-derecha.svg')); ?>" class="iconosFlechas"></a></td>
            <?php elseif($item->white_ribbon_product_type == 'App\Models\WhiteWasteRibbon'): ?>
            <td><a href="<?php echo e(route('whiteWasteRibbon.show',$item->white_ribbon_product_id)); ?>"><img src="<?php echo e(asset('images/flecha-derecha.svg')); ?>" class="iconosFlechas"></a></td>
            <?php elseif($item->white_ribbon_product_type == 'App\Models\Ribbon'): ?>
            <td><a href="<?php echo e(route('ribbon.show',$item->white_ribbon_product_id)); ?>"><img src="<?php echo e(asset('images/flecha-derecha.svg')); ?>" class="iconosFlechas"></a></td>
            <?php endif; ?>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>
    </div>


    <?php echo $__env->make('whiteRibbons.modalTypeSelection', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.formulario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Galmonte\Desktop\MINABI-project\resources\views/whiteRibbons/show.blade.php ENDPATH**/ ?>