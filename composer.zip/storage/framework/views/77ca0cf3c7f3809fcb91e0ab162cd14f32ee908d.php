<div class="modal fade" id="edit<?php echo e($contact->id); ?>">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><b>Editar Contacto</b></h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <form id="formContactEdit<?php echo e($contact->id); ?>" method="POST" action="<?php echo e(route('provider.update', $contact->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="modal-body">
                    <div class="form-group">
                        <label>Télefono:</label>
                        <input type="number" class="form-control" name="telefono" id="telefono<?php echo e($contact->id); ?>" value=<?php echo e($contact->telefono); ?>>
                        <div class="telefono-error<?php echo e($contact->id); ?>"></div>
                    </div>
                    <div class="form-group">
                        <label>Nombre(s):</label>
                        <input type="text" class="form-control" name="nombre" id="nombre<?php echo e($contact->id); ?>" value=<?php echo e($contact->nombre); ?>>
                        <div class="nombre-error<?php echo e($contact->id); ?>"></div>
                    </div>
                    <div class="form-group">
                        <label>Apellidos:</label>
                        <input type="text" class="form-control" name="apellidos" id="apellidos<?php echo e($contact->id); ?>" value=<?php echo e($contact->apellidos); ?>>
                        <div class="apellidos-error<?php echo e($contact->id); ?>"></div>
                    </div>
                    <div class="form-group">
                        <label>Correo electrónico:</label>
                        <input type="email" class="form-control" name="correoElectronico" id="correoElectronico<?php echo e($contact->id); ?>" value=<?php echo e($contact->correoElectronico); ?>>
                        <div class="correoElectronico-error<?php echo e($contact->id); ?>"></div>
                    </div>
                    <input type="hidden" name="provider_id" value="<?php echo e($provider->id); ?>">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button id="<?php echo e($contact->id); ?>" type="button" name="contactForm" class="btn btn-success" onclick="formValidationEdit(this)">Guardar Cambios</button>
                </div>
            </form>
        </div>
    </div>
</div><?php /**PATH C:\Users\Galmonte\Desktop\MINABI-project\resources\views/contacts/edit.blade.php ENDPATH**/ ?>