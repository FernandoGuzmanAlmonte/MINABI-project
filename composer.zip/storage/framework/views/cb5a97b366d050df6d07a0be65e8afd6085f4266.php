

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class=" justify-content-center text-center mt-4">
        <img src=<?php echo e(asset('images/logotipo.png')); ?> width="170" height="300" class="my-5" alt="">
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Galmonte\Desktop\MINABI-project\resources\views/home.blade.php ENDPATH**/ ?>