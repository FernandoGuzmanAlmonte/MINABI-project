

<?php $__env->startSection('title', 'Registrar Usuarios'); ?>

<?php $__env->startSection('imgUrl',  asset('images/bolsa-de-papel.svg')); ?>

<?php $__env->startSection('namePage', 'Registrar Usuarios'); ?>

<?php $__env->startSection('form'); ?>
<form action="<?php echo e(route('user.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-lg-12 d-flex mt-2">
            <div class="col-lg-4 px-2">
                <label>Nombre</label>
                <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required>
            </div>
            <div class="col-lg-4 px-2">
                <label>Correo</label>
                <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>
            </div>
            <div class="col-lg-4 px-2">
                <label>Contraseña</label>
                <input type="password" class="form-control" name="password"  required >
            </div>
        </div>

        <div class="col-lg-12 d-flex mt-2">
            <div class="col-lg-4 px-2">
            <select class="form-control" name="role_id">
                <option selected value="" class="text-muted" disabled>--seleccione un rol--</option>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value=<?php echo e($rol->id); ?>>
                        <?php echo e($rol->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            </div>
        </div>

        <div class="col-12 mt-4 mb-4 text-center">
            <a class="btn btn-danger mx-3" href="<?php echo e(route('user.index')); ?>">Cancelar</a>
            <button type="submit" class="btn btn-success mx-3">Guardar</button>
        </div> 
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.formulario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Galmonte\Desktop\MINABI-project\resources\views/users/register.blade.php ENDPATH**/ ?>