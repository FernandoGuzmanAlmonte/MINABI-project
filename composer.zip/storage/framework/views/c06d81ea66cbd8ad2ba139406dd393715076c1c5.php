

<?php $__env->startSection('title', 'Bobinas'); ?>

<?php $__env->startSection('imgUrl',  asset('images/base-de-datos.svg')); ?>

<?php $__env->startSection('namePage', 'Bobinas'); ?>

<?php $__env->startSection('form'); ?>
<form action="<?php echo e(route('coil.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="row">
    <div class="col-lg-12 d-flex mt-2">
        <div class="col-lg-4 px-2">
            <label>Nomenclatura</label>
            <input type="text" class="form-control" name="nomenclatura" value="<?php echo e(old('nomenclatura')); ?>" id="nomenclaturas" readonly>
            <?php $__errorArgs = ['nomenclatura'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <br>
                <div class="alert alert-danger">
                    <small><?php echo e($message); ?></small>
                </div>
                <br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-lg-4 px-2">
            <label><span class="required">*</span>Fecha llegada</label>
            <input type="date" class="form-control" name="fArribo" value="<?php echo e(old('fArribo')); ?>" onblur="llenaNomen()" id="fArribo">
            <?php $__errorArgs = ['fArribo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <br>
                <div class="alert alert-danger">
                <small><?php echo e($message); ?></small>
                </div>
                <br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-lg-4 px-2">
            <label><span class="required">*</span>Tipo bobina</label>
            <select class="form-control" name="coil_type_id" id="tipo" onblur="llenaNomen()">
                <option selected value="" class="text-muted" disabled>--seleccione tipo de bobina--</option>
                <?php $__currentLoopData = $coilTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coilType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value=<?php echo e($coilType->id); ?> <?php echo e(($coilType->id == old('coil_type_id')) ? 'selected' : ''); ?>>
                        <?php echo e($coilType->alias); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['coil_type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <br>
                <div class="alert alert-danger">
                <small><?php echo e($message); ?></small>
                </div>
                <br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="col-lg-12 d-flex mt-3">
        <div class="col-lg-4 px-2">
            <label><span class="required">*</span>Proveedor</label>
            <?php if( Route::is('coil.createFromProvider') ): ?>
                <input type="text" class="form-control" value=<?php echo e($provider->nombreEmpresa); ?> readonly>    
            <?php else: ?>
                <select class="form-control" name="provider_id">
                    <option selected value="" class="text-muted" disabled>--seleccione proveedor--</option>
                    <?php $__currentLoopData = $providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value=<?php echo e($provider->id); ?> <?php echo e(($provider->id == old('provider_id')) ? 'selected' : ''); ?>>
                            <?php echo e($provider->nombreEmpresa); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            <?php endif; ?>
            
            <?php $__errorArgs = ['provider_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <br>
                <div class="alert alert-danger">
                <small><?php echo e($message); ?></small>
                </div>
                <br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-lg-4 px-2">
            <label>Status</label>
            <input type="datetime" class="form-control" name="status" value="DISPONIBLE" readonly>
            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <br>
                <div class="alert alert-danger">
                <small><?php echo e($message); ?></small>
                </div>
                <br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-lg-4 px-2">
            <label><span class="required">*</span>Largo (metros)</label>
            <input type="number" step="0.0001" class="form-control" name="largoM" value="<?php echo e(old('largoM')); ?>">
            <?php $__errorArgs = ['largoM'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <br>
                <div class="alert alert-danger">
                <small><?php echo e($message); ?></small>
                </div>
                <br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="col-lg-12 d-flex mt-3">
        <div class="col-lg-4 px-2">
            <label><span class="required">*</span>Peso Bruto (Kg)</label>
            <input type="number" step="0.0001" class="form-control" name="pesoBruto" value="<?php echo e(old('pesoBruto')); ?>">
            <?php $__errorArgs = ['pesoBruto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <br>
                <div class="alert alert-danger">
                <small><?php echo e($message); ?></small>
                </div>
                <br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-lg-4 px-2">
            <label>Peso Neto (Kg)</label>
            <input type="number" step="0.0001" class="form-control" name="pesoNeto" value="0" readonly>
            <?php $__errorArgs = ['pesoNeto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <br>
                <div class="alert alert-danger">
                <small><?php echo e($message); ?></small>
                </div>
                <br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-lg-4 px-2">
            <label>Peso Utilizado (Kg)</label>
            <input type="number" step="0.0001" class="form-control" name="pesoUtilizado" value="0" readonly>
        </div>
    </div>

    <div class="col-lg-12 d-flex mt-3">
        <div class="col-lg-4 px-2">
            <label>Diametro Exterior</label>
            <input type="number" step="0.0001" class="form-control" name="diametroExterno" value="<?php echo e(old('diametroExterno')); ?>">
        </div>
        <div class="col-lg-4 px-2">
            <label>Diametro Bobina</label>
            <input type="number" step="0.0001" class="form-control" name="diametroBobina" value="<?php echo e(old('diametroBobina')); ?>">
        </div>
        <div class="col-lg-4 px-2">
            <label>Diametro Interior</label>
            <input type="number" step="0.0001" class="form-control" name="diametroInterno" value="<?php echo e(old('diametroInterno')); ?>">
        </div>
    </div>

    <div class="col-lg-12 d-flex mt-3">
        <div class="col-lg-4 px-2">
            <label><span class="required">*</span>Costo</label>
            <input type="number" step="0.0001" class="form-control" name="costo" value="<?php echo e(old('costo')); ?>">
            <?php $__errorArgs = ['costo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <br>
                <div class="alert alert-danger">
                <small><?php echo e($message); ?></small>
                </div>
                <br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    <div class="col-lg-12 d-flex mt-4">
        <div class="col-lg-12 px-2">
            <label>Observaciones</label>
            <textarea rows="3" class="form-control" name="observaciones"><?php echo e(old('observaciones')); ?></textarea>
        </div>
    </div>
    
    <?php if( Route::is('coil.createFromProvider') ): ?>
        <input type="hidden" name="provider_id" value="<?php echo e($provider->id); ?>">
    <?php endif; ?>

    <div class="col-12 mt-4 mb-4 text-center">
        <?php if( Route::is('coil.createFromProvider') ): ?>
            <a class="btn btn-danger mx-3" href="<?php echo e(route('provider.show', $provider)); ?>">Cancelar</a>
        <?php else: ?>
            <a class="btn btn-danger mx-3" href="<?php echo e(route('coil.index')); ?>">Cancelar</a>
        <?php endif; ?>
        <button type="submit" class="btn btn-success mx-3">Guardar</button>
    </div>
</div>

</form>
<script type="text/javascript">
    function llenaNomen(){
var fecha = document.getElementById("fArribo");
var tipo = document.getElementById("tipo");
var seleccion = tipo.options[tipo.selectedIndex].text;
var folio =  document.getElementById("nomenclaturas");
fecha = fecha.value.replace(/-/g, "");
if(seleccion == "--seleccione tipo de bobina--")
folio.value = "MNB"+fecha.substring(6,8)+fecha.substring(4,6)+fecha.substring(0,4);
else
folio.value = "MNB"+seleccion+fecha.substring(6,8)+fecha.substring(4,6)+fecha.substring(0,4);
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.formulario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Galmonte\Desktop\MINABI-project\resources\views/coils/create.blade.php ENDPATH**/ ?>