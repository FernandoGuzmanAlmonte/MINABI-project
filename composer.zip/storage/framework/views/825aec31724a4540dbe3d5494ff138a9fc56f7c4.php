

<?php $__env->startSection('title', 'Proveedores'); ?>

<?php $__env->startSection('imgUrl',  asset('images/proveedor.svg')); ?>

<?php $__env->startSection('namePage', 'Editar Proveedor ' . $provider->id); ?>

<?php $__env->startSection('form'); ?>
<form action="<?php echo e(route('provider.update', $provider->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="row">
        <div class="col-lg-12 d-flex mt-2">
            <div class="col-lg-4 px-2">
                <label><span class="required">*</span> Nombre Empresa</label>
                <input type="text" class="form-control" name="nombreEmpresa" value="<?php echo e(old('nombreEmpresa', $provider->nombreEmpresa)); ?>">
                <?php $__errorArgs = ['nombreEmpresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger mt-2">
                        <small><?php echo e($message); ?></small>
                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-lg-4 px-2">
                <label><span class="required">*</span> Dirección</label>
                <input type="text" class="form-control" name="direccion" value="<?php echo e(old('direccion', $provider->direccion)); ?>">
                <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger mt-2">
                        <small><?php echo e($message); ?></small>
                    </div>             
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-lg-4 px-2">
                <label>Pagina web</label>
                <input type="text" class="form-control" name="paginaWeb" value="<?php echo e(old('paginaWeb', $provider->paginaWeb)); ?>">
                <?php $__errorArgs = ['paginaWeb'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger mt-2">
                        <small><?php echo e($message); ?></small>
                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="col-lg-12 d-flex mt-3">
            <div class="col-lg-4 px-2">
                <label><span class="required">*</span> Estado</label>
                <input type="text" class="form-control" name="estado" value="<?php echo e(old('estado', $provider->estado)); ?>">
                <?php $__errorArgs = ['estado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger mt-2">
                        <small><?php echo e($message); ?></small>
                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="col-12 mt-3 text-center">
            <a class="btn btn-danger mx-3" href="<?php echo e(route('provider.show', $provider)); ?>">Cancelar</a>
            <button type="submit" name="providerForm" class="btn btn-success mx-3">Guardar</button>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.formulario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Galmonte\Desktop\MINABI-project\resources\views/providers/edit.blade.php ENDPATH**/ ?>