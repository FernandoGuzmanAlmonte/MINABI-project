

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="mt-5"><img src="<?php echo $__env->yieldContent('imgUrl'); ?>" class="iconoTitle"> <?php echo $__env->yieldContent('namePage'); ?> </h1>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <a class="btn btn-success float-right my-3" href="<?php echo $__env->yieldContent('route'); ?>"> Nuevo </a>
        </div>
    </div> 
    
<!-- Filtrado -->
    <?php echo $__env->yieldContent('filtrado'); ?>
    
<!-- tabla -->
    <div class="row">
        <div class="col-lg-12">
            <table class="table table-striped my-4" >
                <thead class="bg-info">
                <!--info de cada tabla-->
                    <?php echo $__env->yieldContent('table'); ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12 d-flex justify-content-center">
            <?php echo $__env->yieldContent('paginacion'); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Galmonte\Desktop\MINABI-project\resources\views/layouts/tablaIndex.blade.php ENDPATH**/ ?>