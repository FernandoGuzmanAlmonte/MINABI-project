

<?php $__env->startSection('title', 'Reporte bobinas'); ?>

<?php $__env->startSection('imgUrl',  asset('images/bobina.svg')); ?>

<?php $__env->startSection('namePage', 'Reporte de almacen de bobinas'); ?>

<?php $__env->startSection('table'); ?>
    <script type="text/javascript">   
        function insertar()
        {
            var bobinas = <?php echo json_encode($bobinas, 15, 512) ?>;
            for(i = 0; i < bobinas.length; i++)
            {
                var medidaId = bobinas[i].medida;
                var providerId = bobinas[i].proveedor;
                $('#medida' + medidaId + providerId).text(bobinas[i].medida);
                $('#peso'   + medidaId + providerId).text(bobinas[i].peso);
            }
            console.log(bobinas);
        }
    </script>
    
    <table class="table table-striped my-4" id="tabla">
        <thead class="bg-info">
            <tr>
                
                <th scope="col">Tamaño</th>            
                <?php $__currentLoopData = $providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th><?php echo e($provider->nombreEmpresa); ?></th>
                    <th>Peso (KG)</th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        </thead>
        <tbody id="table">
            <?php $__currentLoopData = $medidas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medida): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($medida->id); ?></td>
                    <?php $__currentLoopData = $providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td id="medida<?php echo e($medida->id . $provider->id); ?>"></th>
                        <td id="peso<?php echo e($medida->id . $provider->id); ?>"></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <script type="text/javascript">   
            insertar();
        </script>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.tablaIndexSinAgregar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Galmonte\Desktop\MINABI-project\resources\views/coils/reporteria.blade.php ENDPATH**/ ?>