

<?php $__env->startSection('title', 'Bobina cinta blanca'); ?>

<?php $__env->startSection('imgUrl',  asset('images/base-de-datos.svg')); ?>

<?php $__env->startSection('namePage', 'Bobinas cinta blanca'); ?>

<?php $__env->startSection('form'); ?>
<form action="<?php echo e(route('whiteCoil.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="row">
    <div class="col-lg-12 d-flex mt-2">
        <div class="col-lg-4 px-2">
            <label><span class="required">*</span> Nomenclatura</label>
            <input type="text" class="form-control" name="nomenclatura" value="<?php echo e(old('nomenclatura')); ?>" id="nomenclaturas" readonly>
            <?php $__errorArgs = ['nomenclatura'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <br>
                <div class="alert alert-danger">
                    <small><?php echo e($message); ?></small>
                </div>
                <br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-lg-4 px-2">
            <label><span class="required">*</span> Fecha llegada</label>
            <input type="date" class="form-control" name="fArribo" value="<?php echo e(old('fArribo')); ?>" onblur="llenaNomen()" id="fArribo">
            <?php $__errorArgs = ['fArribo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <br>
                <div class="alert alert-danger">
                <small><?php echo e($message); ?></small>
                </div>
                <br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <script type="text/javascript">
            function llenaNomen(){
                var fecha = document.getElementById("fArribo");
                var folio =  document.getElementById("nomenclaturas");
                fecha = fecha.value.replace(/-/g, "");
                folio.value = "MNB"+fecha.substring(6,8)+fecha.substring(4,6)+fecha.substring(1,4);
            }
        </script>
        <div class="col-lg-4 px-2">
            <label>Tipo bobina</label>
            <select class="form-control" name="coil_type_id">
                <option selected value="" class="text-muted" disabled>--seleccione tipo de bobina--</option>
                <?php $__currentLoopData = $coilTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coilType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value=<?php echo e($coilType->id); ?>>
                        <?php echo e($coilType->alias); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <option value="">Ninguno</option>
            </select>
        </div>
    </div>

    <div class="col-lg-12 d-flex mt-3">
        <div class="col-lg-4 px-2">
            <label>Proveedor</label>
            <select class="form-control" name="provider_id">
                <option selected value="" class="text-muted" disabled>--seleccione proveedor--</option>
                <?php $__currentLoopData = $providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value=<?php echo e($provider->id); ?>>
                        <?php echo e($provider->nombreEmpresa); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <option value="">Ninguno</option>
            </select>
            
            <?php $__errorArgs = ['provider_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <br>
                <div class="alert alert-danger">
                <small><?php echo e($message); ?></small>
                </div>
                <br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-lg-4 px-2">
            <label><span class="required">*</span> Status</label>
            <input type="datetime" class="form-control" name="status" value="DISPONIBLE" readonly>
            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <br>
                <div class="alert alert-danger">
                <small><?php echo e($message); ?></small>
                </div>
                <br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-lg-4 px-2">
            <label><span class="required">*</span> Costo</label>
            <input type="number" step="0.0001" class="form-control" name="costo" value="<?php echo e(old('costo')); ?>">
            <?php $__errorArgs = ['costo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <br>
                <div class="alert alert-danger">
                <small><?php echo e($message); ?></small>
                </div>
                <br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="col-lg-12 d-flex mt-3">
        <div class="col-lg-4 px-2">
            <label><span class="required">*</span> Peso( Kg)</label>
            <input type="number" step="0.0001" class="form-control" name="peso" value="<?php echo e(old('peso')); ?>">
            <?php $__errorArgs = ['peso'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <br>
            <div class="alert alert-danger">
            <small><?php echo e($message); ?></small>
            </div>
            <br>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-lg-4 px-2">
            <label><span class="required">*</span> Peso Utilizado (Kg)</label>
            <input type="number" step="0.0001" class="form-control" name="pesoUtilizado" value="0" readonly>
        </div>
    </div>

    <div class="col-lg-12 d-flex mt-4">
        <div class="col-lg-12 px-2">
            <label>Observaciones</label>
            <textarea rows="3" class="form-control" name="observaciones"><?php echo e(old('observaciones')); ?></textarea>
        </div>
    </div>
    
   

    <div class="col-12 mt-4 mb-4 text-center">
        <a class="btn btn-danger mx-3" href="<?php echo e(route('whiteCoil.index')); ?>">Cancelar</a>
        <button type="submit" class="btn btn-success mx-3">Guardar</button>
    </div>
</div>

</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.formulario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Galmonte\Desktop\MINABI-project\resources\views/whiteCoils/create.blade.php ENDPATH**/ ?>