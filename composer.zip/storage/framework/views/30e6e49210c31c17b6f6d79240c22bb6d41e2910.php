<div class="modal fade" id="edit<?php echo e($bagMeasure->id); ?>">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><b>Editar Medida de Bolsa</b></h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <form id="formBagMeasureEdit<?php echo e($bagMeasure->id); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="modal-body row">
                    <div class="col-lg-6 px-2">
                        <label>Ancho:</label>
                        <input type="number" step="0.0001" class="form-control" name="ancho" id="ancho<?php echo e($bagMeasure->id); ?>" value="<?php echo e($bagMeasure->ancho); ?>">
                        <div class="ancho-error<?php echo e($bagMeasure->id); ?>"></div>
                    </div>
                    <div class="col-lg-6 px-2">
                        <label>Largo:</label>
                        <input type="number" step="0.0001" class="form-control" name="largo" id="largo<?php echo e($bagMeasure->id); ?>" value="<?php echo e($bagMeasure->largo); ?>">
                        <div class="largo-error<?php echo e($bagMeasure->id); ?>"></div>
                    </div>
                    <input type="hidden" name="coil_type_id" value="<?php echo e($coilType->id); ?>">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button id="<?php echo e($bagMeasure->id); ?>" type="button" name="bagMeasureForm" class="btn btn-success" onclick="formValidationEdit(this)">Guardar Cambios</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Galmonte\Desktop\MINABI-project\resources\views/bagMeasures/edit.blade.php ENDPATH**/ ?>