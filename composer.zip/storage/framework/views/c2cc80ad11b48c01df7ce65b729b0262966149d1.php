

<?php $__env->startSection('title', 'Proveedores'); ?>

<?php $__env->startSection('imgUrl',  asset('images/bolsa-de-papel.svg')); ?>

<?php $__env->startSection('namePage', 'Bolsa ' . $bag->nomenclatura); ?>

<?php $__env->startSection('retornar'); ?>
<a href="<?php echo e(route('ribbonProduct.index')); ?>" ><img src="<?php echo e(asset('images/flecha-derecha.svg')); ?>" class="iconosFlechas mirror"></a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('form'); ?>
<div class="row">
    <div class="col-lg-12 d-flex mt-2">
        <div class="col-lg-4 px-2">
            <label>Nomenclatura</label>
            <input type="text" class="form-control" name="nomenclatura" value=<?php echo e($bag->nomenclatura); ?> disabled>
        </div>
        <div class="col-lg-4 px-2">
            <label>Status</label>
            <input type="text" class="form-control" name="status" value=<?php echo e($bag->status); ?> disabled>
        </div>
        <div class="col-lg-4 px-2">
            <label>Cantidad</label>
            <input type="text" class="form-control" name="cantidad" value=<?php echo e($bag->cantidad); ?> disabled>
        </div>
    </div>
    <div class="col-lg-12 d-flex mt-3">
        <div class="col-lg-4 px-2">
            <label>Temperatura</label>
            <input type="text" class="form-control" name="temperatura" value=<?php echo e($bag->temperatura); ?> disabled>
        </div>
        <div class="col-lg-4 px-2">
            <label>Fecha Inicio</label>
            <input type="date" class="form-control" name="fechaInicioTrabajo" value=<?php echo e($bag->fechaInicioTrabajo); ?> disabled>
        </div>
        <div class="col-lg-4 px-2">
            <label>Hora Inicio</label>
            <input type="time" class="form-control" name="horaInicioTrabajo" value=<?php echo e($bag->horaInicioTrabajo); ?> disabled>
        </div>
    </div>
    <div class="col-lg-12 d-flex mt-3">
        <div class="col-lg-4 px-2">
            <label>Medida (largo x ancho)</label>
            <input type="text" class="form-control" name="bag_measure_id" value="<?php echo e($bag->bagMeasure->largo .' x '. $bag->bagMeasure->ancho . ($cinta->isEmpty()? ' ' :  ' C/P')); ?>" disabled>
        </div>
        <div class="col-lg-4 px-2">
            <label>Fecha Termino</label>
            <input type="date" class="form-control" name="fechaFinTrabajo" value=<?php echo e($bag->fechaFinTrabajo); ?> disabled>
        </div>
        <div class="col-lg-4 px-2">
            <label>Hora Termino</label>
            <input type="time" class="form-control" name="horaFinTrabajo" value=<?php echo e($bag->horaFinTrabajo); ?> disabled>
        </div>
    </div>
    <div class="col-lg-12 d-flex mt-3">
        <div class="col-lg-4 px-2">
            <label>Tipo de unidad</label>
            <input type="text" class="form-control" name="tipoUnidad" value=<?php echo e($bag->tipoUnidad); ?> disabled>
        </div>
        <div class="col-lg-4 px-2">
            <label>Peso (Kg)</label>
            <input type="text" class="form-control" name="peso" value=<?php echo e($bag->peso); ?> disabled>
        </div>
        <div class="col-lg-4 px-2">
            <label>Velocidad</label>
            <input type="text" class="form-control" name="velocidad" value=<?php echo e($bag->velocidad); ?> disabled>
        </div>
    </div>
    <div class="col-lg-12 d-flex mt-3">
        <div class="col-lg-4 px-2">
            <label>Cliente Stock</label>
            <input type="text" class="form-control" name="clienteStock" value=<?php echo e($bag->clienteStock); ?> disabled>
        </div>
    </div>
    <div class="col-lg-12 d-flex mt-3">
        <div class="col-lg-12 px-2">
            <label>Observaciones</label>
            <textarea rows="3" class="form-control" name="observaciones" disabled><?php echo e($bag->observaciones); ?></textarea>
        </div>  
    </div>

    <div class="col-lg-12 mt-4 mb-2">
        <h3><img src="<?php echo e(asset('images/empleado.svg')); ?>" class="iconoTitle"> Empleados</h3>
        <table class="table table-striped my-4" >
            <thead class="bg-info">
            <tr>
                <th scope="col">#</th>
                <th scope="col">Nombre</th>
                <th scope="col">Minutos Trabajados</th>
                <th scope="col">Sueldo por hora</th>
                <th scope="col">Costo de Mano de obra</th>
            </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $bag->employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row" class="align-middle"><?php echo e($employee->id); ?></th>
                        <td class="align-middle"><?php echo e($employee->nombre); ?></td>
                        <td class="align-middle"><?php echo e($minutosLaborados); ?></td>
                        <td class="align-middle">$ <?php echo e($employee->sueldoHora); ?></td>
                        <td class="align-middle">$ <?php echo e(round(($employee->sueldoHora/60)*$minutosLaborados,4)); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php if($coil->status == 'TERMINADA'): ?>
    
    <div class="col-12 mt-2 mb-2 text-right">
        <h3 class="text-left"><img src="<?php echo e(asset('images/moneda-de-dinero.svg')); ?>" class="iconoTitle"> Costos</h3>
        <div class="d-flex">
            <div class="h5 col-10 ">Costo Rollo=</div>
            <div class="h5 col-2 ">$ <?php echo e(round($bag->costoTotal, 4)); ?></div>
        </div>
        <div class="d-flex">
            <div class="h5 col-10">Costo de mano de obra =</div>
            <div class="h5 col-2">$ <?php echo e(($bag->employees->sum('sueldoHora')/60)*$minutosLaborados); ?></div>
        </div>
        <hr>
        <div class="d-flex">
            <div class="h5 col-10">Total =</div>
            <div class="h5 col-2">$ <?php echo e(round((($bag->employees->sum('sueldoHora')/60)*$minutosLaborados)+ $bag->costoTotal,4)); ?></div>
        </div>
        <div class="d-flex">
            <div class="h5 col-10">Costo por unidad =</div>
            <div class="h5 col-2">$ <?php echo e(round(((($bag->employees->sum('sueldoHora')/60)*$minutosLaborados)+ $bag->costoTotal)/$bag->cantidad,4)); ?></div>
        </div>
    </div>
    <?php endif; ?> 
    <div class="col-12 mt-3 text-center">
        <a class="btn btn-warning mx-3" href="<?php echo e(route('bag.edit', $bag)); ?>">Editar</a>
    </div>
    <div class="col-lg-12 d-flex mt-5">
        <h3><img src="<?php echo e(asset('images/rollo-de-papel.svg')); ?>" class="iconoTitle">Rollo <a href="<?php echo e(route('ribbon.show', $ribbon->id)); ?>"><small>Ver Rollo</small></a> </h3>
    </div>
    
    <div class="col-lg-12 d-flex mt-3">
        <div class="col-lg-4 px-2">
            <label>Nomenclatura</label>
            <input type="text" class="form-control" name="coilNomenclatura" value="<?php echo e($ribbon->nomenclatura); ?>" disabled>
        </div>
        <div class="col-lg-4 px-2">
            <label>Fecha Adquisición</label>
            <input type="datetime" class="form-control" name="coilfArribo" value="<?php echo e($ribbon->fechaInicioTrabajo); ?>" disabled>
        </div>
        <div class="col-lg-4 px-2">
            <label>Status</label>
            <input type="text" class="form-control" name="coilStatus" value="<?php echo e($ribbon->status); ?>" disabled>
        </div>
    </div>

    <div class="col-lg-12 d-flex mt-5">
        <h3><img src="<?php echo e(asset('images/bobina.svg')); ?>" class="iconoTitle">Bobina <a href="<?php echo e(route('coil.show', $coil->id)); ?>"><small>Ver Bobina</small></a> </h3>
    </div>
    
    <div class="col-lg-12 d-flex mt-3">
        <div class="col-lg-4 px-2">
            <label>Nomenclatura</label>
            <input type="text" class="form-control" name="coilNomenclatura" value="<?php echo e($coil->nomenclatura); ?>" disabled>
        </div>
        <div class="col-lg-4 px-2">
            <label>Fecha Adquisición</label>
            <input type="datetime" class="form-control" name="coilfArribo" value="<?php echo e($coil->fArribo); ?>" disabled>
        </div>
        <div class="col-lg-4 px-2">
            <label>Status</label>
            <input type="text" class="form-control" name="coilStatus" value="<?php echo e($coil->status); ?>" disabled>
        </div>
    </div>
    <?php if(!$cinta->isEmpty() ): ?>
    <div class="col-lg-12 my-5">
        <h3><img src="<?php echo e(asset('images/cinta.svg')); ?>" class="iconoTitle"> Cinta blanca</h3>
        
        <table class="table table-striped my-4" >
            <thead class="bg-info">
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Nomenclatura</th>
                    <th scope="col">Fecha Adquisición</th>
                    <th scope="col">Status</th>
                    <th scope="col"></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $cinta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row" class="align-middle"><?php echo e($item->id); ?></th>
                    <td class="align-middle"><?php echo e($item->nomenclatura); ?></td>
                    <td class="align-middle"><?php echo e($item->fArribo); ?></td>
                    <td class="align-middle"><label class="btn btn-outline-<?php echo e(($item->status == 'DISPONIBLE') ? 'success' : 'danger'); ?> m-0"><?php echo e($item->status); ?></label></td>
                    <!--Realizamos if para validacion de adonde dirgir el show-->
                    
                    <td><a href="<?php echo e(route('whiteRibbon.show',$item->id)); ?>"><img src="<?php echo e(asset('images/flecha-derecha.svg')); ?>" class="iconosFlechas"></a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.formulario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Galmonte\Desktop\MINABI-project\resources\views/bags/show.blade.php ENDPATH**/ ?>