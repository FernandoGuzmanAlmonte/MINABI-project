

<?php $__env->startSection('title', 'Rollos de cinta blanca'); ?>

<?php $__env->startSection('imgUrl',  asset('images/rollo-de-papel.svg')); ?>

<?php $__env->startSection('namePage', 'Rollos de cinta blanca'); ?>

<?php $__env->startSection('filtrado'); ?>
    <form action="<?php echo e(route('whiteCoilProduct.index')); ?>" method="GET" class="row g-3 mt-5" id="formOrder">
        <div class="col-lg-5">
                <h6 class="textoConLinea"><span>Ordenar</span></h6>
                <div class="row">
                    <div class="col-lg-7 d-flex align-items-center">
                        <div class="select">
                            <select class="form-control" name="orderBy" onchange="actualizarTabla()">
                                <option value="id" <?php echo e(($orderBy == 'id') ? 'selected' : ''); ?>>Ordenar por Identificador</option>
                                <option value="nomenclatura" <?php echo e(($orderBy == 'nomenclatura') ? 'selected' : ''); ?>>Ordenar por Nomenclatura</option>
                                <option value="fAdquisicion" <?php echo e(($orderBy == 'fAdquisicion') ? 'selected' : ''); ?>>Ordenar por Fecha Adquisición</option>
                                <option value="status" <?php echo e(($orderBy == 'status') ? 'selected' : ''); ?>>Ordenar por Status</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-5">
                        <div class="row">
                            <div class="col-lg-2 d-flex align-items-center">
                                <div class="mt-1 mb-0 form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="order" id="radioAsc" value="ASC" onclick="cambioOrdenAscendente()">
                                </div>
                            </div>
                            <div class="col-lg-10 d-flex align-items-center">
                                <h5 class="mt-1 mb-0">
                                    <span class="badge badge-pill badge-light pr-4" id="badgeAsc" style="color:#343A40; font-weight:normal; width: 95%;">
                                        <img src=<?php echo e(asset('images/ascendente-black.svg')); ?>  class="iconosFiltrado" id="imgAsc">
                                        Ascendente
                                    </span>
                                </h5>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-2 d-flex align-items-center">
                                <div class="mt-4 mb-0 form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="order" id="radioDesc" value="DESC" onclick="cambioOrdenDescendente()">
                                </div>
                            </div>
                            <div class="col-lg-10 d-flex align-items-center">
                                <h5 class="mt-4 mb-0">
                                    <span class="badge badge-pill badge-light pr-4" id="badgeDesc" style="color:#343A40; font-weight:normal; width: 95%;">
                                        <img src=<?php echo e(asset('images/descendente-black.svg')); ?>  class="iconosFiltrado" id="imgDesc">
                                        Descendente
                                    </span>
                                </h5>
                            </div>
                        </div>
                    </div>
                </div>
        </div>        
        <div class="col-lg-7 d-flex align-items-center">
            <div class="col-lg-10 pr-0 pl-5">
                <input class="form-control" style="width: 100%" type="search" placeholder="Nomenclatura..." name="nomenclatura" value="<?php echo e(($nomenclatura != '') ? $nomenclatura : ''); ?>">
            </div>
            <div class="col-lg-2 pl-0 pr-0">
                <button class="form-control btn btn-secondary pl-2" style="width: 100%" type="submit">
                    <img src=<?php echo e(asset('images/buscar.svg')); ?>  class="iconosPequeños float-left">
                    Buscar
                </button>
            </div>   
        </div>
        <div class="col-lg-6 d-flex">
            <h6 class="textoConLinea mt-3"><span>Filtrar</span></h6>                 
        </div>
        <div class="col-lg-12 d-flex">
            <div class="col-lg-3 pl-0 pr-0">
                <div class="row">
                    <div class="col-lg-9 mb-1 mt-1">
                        <div class="form-check float-right">
                            <input class="form-check-input" type="checkbox" onchange="cambiarStatus(this)" <?php echo e(($status) ? 'checked' : ''); ?>>
                            <label class="form-check-label float-right text-muted mr-3" for="flexCheckDefault" id="labelStatus">
                                Status
                            </label>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-9">
                        <select class="form-control text-muted" name="status" id="checkStatus" onchange="actualizarTabla()" <?php echo e(($status) ? '' : 'disabled'); ?>>
                            <option value="">--todos--</option>
                            <?php $__currentLoopData = $allStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                                <option <?php echo e(($status == $s->status) ? 'selected' : ''); ?> value="<?php echo e($s->status); ?>"><?php echo e($s->status); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div> 
                </div>
            </div>
            <div class="col-lg-3 pl-0 pr-0">
                <div class="row">
                    <div class="col-lg-9 mb-1 mt-1">
                        <div class="form-check float-right">
                            <input class="form-check-input" type="checkbox" onchange="cambiarFecha(this)"> 
                            <label class="form-check-label float-right text-muted" for="flexCheckDefault" id="labelFecha">
                                Fecha Adquisición
                            </label>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-1 d-flex align-items-center">
                        <img src="<?php echo e(asset('images/fecha-disabled.svg')); ?>" class="iconosPequeños" id="icoFecha">
                    </div> 
                    <div class="col-lg-9">
                        <input class="form-control" type="text" name="fecha" id="daterange" value="" disabled> 
                    </div> 
                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('table'); ?>
<table class="table table-striped my-4" >
    <thead class="bg-info">
<tr>
    <th scope="col">#</th>
    <th scope="col">Nomenclatura</th>
    <th scope="col">Fecha Adquisición</th>
    <th scope="col">Status</th>
    <th scope="col"></th>
  </tr>
</thead>
<tbody id="tableBody">
    <?php $__currentLoopData = $whiteCoilProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <th scope="row" class="align-middle"><?php echo e($item->id); ?></th>
        <td class="align-middle"><?php echo e($item->nomenclatura); ?></td>
        <td class="align-middle"><?php echo e($item->fAdquisicion); ?></td>
        <td class="align-middle"><label class="btn btn-outline-<?php echo e(($item->status == 'DISPONIBLE') ? 'success' : 'danger'); ?> m-0"><?php echo e($item->status); ?></label></td>
        <?php if($item->white_coil_product_type == 'App\Models\WhiteRibbon'): ?>
        <td><a href="<?php echo e(route('whiteRibbon.show',$item->white_coil_product_id)); ?>"><img src="<?php echo e(asset('images/flecha-derecha.svg')); ?>" class="iconosFlechas"></a></td>
        <?php elseif($item->white_coil_product_type == 'App\Models\WhiteWaste'): ?>
        <td><a href="<?php echo e(route('whiteWaste.show',$item->white_coil_product_id)); ?>"><img src="<?php echo e(asset('images/flecha-derecha.svg')); ?>" class="iconosFlechas"></a></td>
        <?php endif; ?>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<div class="d-flex  justify-content-center"><?php echo e($whiteCoilProducts->links()); ?></div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">

    $('#daterange').on('apply.daterangepicker', function(ev, picker) {
        actualizarTabla();
    });

    $('#daterange').daterangepicker(
        {
            "locale": 
            {
                "format": "YYYY-MM-DD",
                "separator": " - ",
                "applyLabel": "Filtrar",
                "cancelLabel": "Cancelar",
                "fromLabel": "Desde",
                "toLabel": "Hasta",
                "customRangeLabel": "Personalizar",
                "daysOfWeek": [
                    "Do",
                    "Lu",
                    "Ma",
                    "Mi",
                    "Ju",
                    "Vi",
                    "Sa"
                ],
                "monthNames": [
                    "Enero",
                    "Febrero",
                    "Marzo",
                    "Abril",
                    "Mayo",
                    "Junio",
                    "Julio",
                    "Agosto",
                    "Setiembre",
                    "Octubre",
                    "Noviembre",
                    "Diciembre"
                ],
                "firstDay": 1
            },
            "opens": "center"
        }
    ); // cargamos el datarange

    function cambioOrdenAscendente()
    {
        ascendente();
        actualizarTabla();
    }

    function cambioOrdenDescendente()
    {
        descendente();
        actualizarTabla();
    }

    function actualizarTabla()
    {
        var form = $("#formOrder");
        var formData = form.serialize(); //variable con el valor de todos los input del formulario
        
        $.ajax({
            url: "<?php echo e(route('whiteCoilProduct.index')); ?>",
            type: 'GET',
            data: formData,
            success: function(response)
                     {
                        var table = document.getElementById('tableBody');
                        var newTable = $(response).find('tbody');
                        $(table).html(newTable.html());
                     },
            error: function(response)
                   {
                        alert(response);
                   }
        });
    }
    
    function ascendente()
    {
        $('#badgeAsc').attr('class', 'badge badge-pill badge-info pr-4');
        $('#badgeAsc').attr('style', 'color:white; font-weight:normal; width: 95%;');
        $('#imgAsc').attr('src', "<?php echo e(asset('images/ascendente-white.svg')); ?>");
        $('#radioAsc').prop('checked', true);
        
        $('#badgeDesc').attr('class', 'badge badge-pill badge-light pr-4');
        $('#badgeDesc').attr('style', 'color:black; font-weight:normal; width: 95%;');
        $('#imgDesc').attr('src', "<?php echo e(asset('images/descendente-black.svg')); ?>");
        $('#radioDesc').prop('checked', false);
    }

    function descendente()
    {
        $('#badgeAsc').attr('class', 'badge badge-pill badge-light pr-4');
        $('#badgeAsc').attr('style', 'color:black; font-weight:normal; width: 95%;');
        $('#imgAsc').attr('src', "<?php echo e(asset('images/ascendente-black.svg')); ?>");
        $('#radioAsc').prop('checked', false);

        $('#badgeDesc').attr('class', 'badge badge-pill badge-info pr-4');
        $('#badgeDesc').attr('style', 'color:white; font-weight:normal; width: 95%;');
        $('#imgDesc').attr('src', "<?php echo e(asset('images/descendente-white.svg')); ?>");
        $('#radioDesc').prop('checked', true);
    }

    function cambiarStatus(checkbox)
    {
        if(checkbox.checked)
        {
            $('#labelStatus').attr('class', 'form-check-label float-right mr-3');

            $('#checkStatus').attr('class', 'form-control');
            $('#checkStatus').prop('disabled', false);
        }
        else
        {
            $('#labelStatus').attr('class', 'form-check-label float-right text-muted mr-3');

            var selectStatus = $('#checkStatus');
            selectStatus.attr('class', 'form-control text-muted');
            selectStatus.prop('disabled', true);
            selectStatus[0].selectedIndex = 0;
        }

        actualizarTabla();
    }

    function cambiarTipo(checkbox)
    {
        if(checkbox.checked)
        {
            $('#labelTipo').attr('class', 'form-check-label float-right mr-3');

            $('#checkTipo').attr('class', 'form-control');
            $('#checkTipo').prop('disabled', false);
        }
        else
        {
            $('#labelTipo').attr('class', 'form-check-label float-right text-muted mr-3');

            var selectStatus = $('#checkTipo');
            selectStatus.attr('class', 'form-control text-muted');
            selectStatus.prop('disabled', true);
            selectStatus[0].selectedIndex = 0;
        }

        actualizarTabla();
    }

    function cambiarFecha(checkbox)
    {
        if(checkbox.checked)
        {
            $('#labelFecha').attr('class', 'form-check-label float-right');
            $('#icoFecha').attr('src', "<?php echo e(asset('images/fecha-enabled.svg')); ?>");

            $('#daterange').attr('class', 'form-control');
            $('#daterange').prop('disabled', false);
        }
        else
        {
            $('#labelFecha').attr('class', 'form-check-label float-right text-muted');
            $('#icoFecha').attr('src', "<?php echo e(asset('images/fecha-disabled.svg')); ?>");

            $('#daterange').attr('class', 'form-control text-muted');
            $('#daterange').prop('disabled', true);

            actualizarTabla();
        }
    }

    function inicializador(){
        if('<?php echo e($order); ?>' == 'ASC')
            ascendente();
        else
            descendente();
    }
    window.onload = inicializador;
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.tablaIndexSinAgregar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Galmonte\Desktop\MINABI-project\resources\views/whiteCoilProducts/index.blade.php ENDPATH**/ ?>